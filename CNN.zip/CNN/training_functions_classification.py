"""Training and testing tools for convnets."""

import torch
import torch.utils.data
import logging
import pandas as pd
from torch.optim.lr_scheduler import MultiStepLR, CyclicLR
import typing
import pathlib
import tqdm
import numpy as np
from sklearn import metrics, preprocessing

def set_up_lr(
    model: torch.nn.Module,
    lr_type: str='standard',
    hyperparam_dict: dict={'lr_highest': 0.001},
    param_set_id: str='0',
) -> dict:
    """"Sets up standard, cyclic, or differential learning rate parameter groups for custom model types (cnn is attribute 'model' in torch model object)"""
    layers = []
    for name, param in model.named_parameters():
        layer = name.split('.')[1]
        if layer not in layers:
            layers.append(layer)

    # define function that defines lr by depth
    if lr_type == "differential":
        def lr_shape_function(depth):
            return hyperparam_dict["lr_highest"]/(depth**hyperparam_dict["lr_shape"] + 1)
    else: 
        def lr_shape_function(depth):
            return hyperparam_dict["lr_highest"]
        
    param_groups = []
    depth = len(layers) - 1
    for layer in layers:
        param_groups.append({
        'name': layer,
        'param_set_id': param_set_id,
        'hyperparam_dict': hyperparam_dict,
        'params': getattr(model.model, layer).parameters(),
        'lr': lr_shape_function(depth)
        })
        depth -= 1
        
    return param_groups

def set_up_scheduler(
    optimizer: torch.optim.Optimizer,
    scheduler_type: str="none",
    total_epochs: int=0,
    base_lr: float=0.001,
    max_lr: float=0.005,
    step_size_up: int=900,
) -> torch.optim.lr_scheduler._LRScheduler:
    
    if scheduler_type == "multistep":
        scheduler_steps = []
        for i in range(10, total_epochs, 10):
            scheduler_steps.append(i)
        scheduler = MultiStepLR(optimizer, scheduler_steps)
        scheduler.__dict__['scheduler_type'] = "multistep"
        
    elif scheduler_type == "cyclic":
        # REPLACE BASE_LR AND MAX_LR
        scheduler = CyclicLR(optimizer, base_lr=base_lr, max_lr=max_lr, cycle_momentum=False, step_size_up=step_size_up)
        scheduler.__dict__['scheduler_type'] = "cyclic"
        
    else:
        scheduler = None
    
    return scheduler

def train(
    model: torch.nn.Module,
    loss: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    train_dataloader: torch.utils.data.DataLoader,
    val_dataloader: torch.utils.data.DataLoader,
    device: torch.device,
    output_dir: pathlib.Path,
    epochs: int=3,
    obs_prop_train: 'float64'=0.78,
    scheduler: torch.optim.lr_scheduler._LRScheduler=None,
    start_epoch: int=0,
    num_epoch_early_stop: int=None,
    id_var_name: str="id",
    verbose: bool=False,
) -> None:
    """Iterate over images using given loss and optimizer to train. Evaluate on the validation set."""

    # initialize all objects to starting states
    param_set_id = optimizer.param_groups[1]["param_set_id"]
    param_dir_name = "param_set_%s" % param_set_id
    optimizer.zero_grad()
    
    # initialize training trackers
    if num_epoch_early_stop is None:
        num_epoch_early_stop = epochs
    train_aucs = []
    val_aucs = []
    train_losses = []
    val_losses = []
    train_mean_mostly_dead_list = []
    val_mean_mostly_dead_list = []
    best_auc = 0
    early_stop_counter = 0
    
    
    
    for epoch in range(start_epoch, epochs):# loop over the dataset multiple times
        full_predictions = np.empty((0,1))
        full_labels = np.empty((0,1))
        full_activations = np.empty((0,model.model.final_fc.in_features))
        # set to training mode, so batchnorm and dropout layers work properly
        model.train()
        logging.info("Epoch %d" % epoch)
        for layer in optimizer.param_groups:
            logging.info("layer name: %s, lr: %.8f" % (layer["name"], layer["lr"]))
        for iteration, data in tqdm.tqdm(enumerate(train_dataloader, 0),
                                         total=len(train_dataloader),
                                         position=0, 
                                         leave=True,
                                         desc = "Progress through batches"):
            # load new images, labels, and structured data
#             images, labels, added_data = data[0], data[1], data[3].to(device)
# #             images, labels, added_data = data[0].to(device), data[1].to(device), data[3].to(device)

# #  z = z.type_as(x)

#             # check final layer activations
#             activations = model.last_layer_activations(images)

#             predictions = model(images, added_data)
#             loss_value = loss(predictions, labels) # either model forward call or loss function must include sigmoid fn
            
            
            loss_value.backward()
            optimizer.step()
            optimizer.zero_grad()

            if scheduler is not None and scheduler.scheduler_type == "cyclic":
                scheduler.step()

            predictions = predictions.detach().cpu().numpy()
            labels = labels.cpu().numpy()
            activations = activations.detach().cpu().numpy()

            full_predictions = np.concatenate((full_predictions, predictions))
            full_labels = np.concatenate((full_labels, labels))
            full_activations = np.concatenate((full_activations, activations))

        if scheduler is not None and scheduler.scheduler_type != "cyclic":
            scheduler.step()
        
        # must have logger set up
        logging.info("\n\nEpoch %d (Parameter Set %s): " % (epoch, param_set_id))
        logging.info("--Train Performance--")
        if verbose : 
            print("\nEpoch %d (Parameter Set %s): " % (epoch, param_set_id))
            print("--Train Performance--")
        
        train_performance = test_metrics(
            prediction_np=full_predictions,
            label_np=full_labels,
            observed_prop=obs_prop_train,
            loss=loss,
            verbose = verbose
        )
        
        train_mean_dead_activations, train_mean_mostly_dead = check_dead_activations(
            full_activations, 
            verbose, 
            return_values=True
        )
        
        train_aucs.append(train_performance["auc"])
        train_losses.append(train_performance["loss"])
        train_mean_mostly_dead_list.append(train_mean_mostly_dead)
        
        # save interim model
        model_filename = "epoch%d_checkpoint_model.pkl" % epoch
        model.cpu()
        torch.save(model.state_dict(), output_dir.joinpath(param_dir_name, "interim_outputs", model_filename))
#         model.to(device)
        
        val_preds, val_labels, val_ids, val_activations = predict(
            model=model,
            dataloader=val_dataloader,
            device=device
        )
        logging.info("--Validation Performance--")
        if verbose :
            print("--Validation Performance--")
        
        val_performance = test_metrics(
            prediction_np=val_preds,
            label_np=val_labels,
            observed_prop=obs_prop_train,
            loss=loss,
            verbose=verbose
        )
        
        val_mean_dead_activations, val_mean_mostly_dead = check_dead_activations(
            val_activations, 
            verbose, 
            return_values=True)
        
        val_aucs.append(val_performance["auc"])
        val_losses.append(val_performance["loss"])
        val_mean_mostly_dead_list.append(val_mean_mostly_dead)
        
        # save interim predictions
        preds_filename = "epoch%d_preds.feather" % epoch
        preds_np = np.concatenate((val_ids, val_preds, val_labels), 1)
        preds_df = pd.DataFrame(preds_np, columns=[id_var_name,"predicted_probability","label"])
        preds_df.to_feather(output_dir.joinpath(param_dir_name, "interim_outputs", preds_filename))
        
        # save best model for access at end of training
        if val_performance["auc"] > best_auc:
            logging.info("new best")
            if verbose:
                print("new best")
            torch.save(model, output_dir.joinpath(param_dir_name, "interim_outputs", "best_model.pt"))
            best_auc = val_performance["auc"]
            best_epoch = epoch
            early_stop_counter = 0
        else:
            early_stop_counter += 1
            if early_stop_counter == num_epoch_early_stop:
                logging.info("\n***********Early Stopping!\n")
                if verbose:
                    print("\n***********Early Stopping!\n")
                break
                

        logging.info("-"*100 + "\n\n")
        if verbose:
            print("-"*100 + "\n\n")
    logging.info("\n Best Epoch = %d \n" % (best_epoch))
    if verbose: 
        print("\n Best Epoch = %d \n" % (best_epoch))
    model = torch.load(output_dir.joinpath(param_dir_name, "interim_outputs", "best_model.pt"))
    return model, {
        'best_auc': best_auc,
        'best_epoch': best_epoch,
        'train_aucs': train_aucs,
        'val_aucs': val_aucs,
        'train_losses': train_losses,
        'val_losses': val_losses,
        'mean_num_mostly_dead_activations_train': train_mean_mostly_dead_list,
        'mean_num_mostly_dead_activations_val': val_mean_mostly_dead_list
    }

def train_indefinitely(
    model: torch.nn.Module,
    loss: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    train_dataloader: torch.utils.data.DataLoader,
    val_dataloader: torch.utils.data.DataLoader,
    device: torch.device,
    output_dir: pathlib.Path,
    num_epoch_early_stop: int=10,
    max_epochs: int=200,
    obs_prop_train: 'float64'=0.78,
    scheduler: torch.optim.lr_scheduler._LRScheduler=None,
    id_var_name: str="id",
    verbose: bool=False,
) -> None:
    """Iterate over images using given loss and optimizer to train. Evaluate on the validation set."""

    # initialize all objects to starting states
    param_set_id = optimizer.param_groups[1]["param_set_id"]
    param_dir_name = "param_set_%s" % param_set_id
    optimizer.zero_grad()
    
    # initialize training trackers
    if num_epoch_early_stop is None:
        num_epoch_early_stop = epochs
    train_aucs = []
    val_aucs = []
    train_losses = []
    val_losses = []
    train_mean_mostly_dead_list = []
    val_mean_mostly_dead_list = []
    best_auc = 0
    early_stop_counter = 0
    epoch = 0
    while early_stop_counter < num_epoch_early_stop and epoch < max_epochs:# loop over the dataset multiple times
        full_predictions = np.empty((0,1))
        full_labels = np.empty((0,1))
        full_activations = np.empty((0,model.model.final_fc.in_features))
        # set to training mode, so batchnorm and dropout layers work properly
        model.train()
        logging.info("Epoch %d" % epoch)
        for layer in optimizer.param_groups:
            logging.info("layer name: %s, lr: %.8f" % (layer["name"], layer["lr"]))
        for iteration, data in tqdm.tqdm(enumerate(train_dataloader, 0),
                                         total=len(train_dataloader),
                                         position=0, 
                                         leave=True,
                                         desc = "Progress through batches"):
            # load new images, labels, and structured data
#             images, labels, added_data = data[0].to(device), data[1].to(device), data[3].to(device)

            # check final layer activations
            activations = model.last_layer_activations(images)

            # boilerplate training iteration
            predictions = model(images, added_data)
            # check gpu usage
            #print("CUDA Memory Allocation: ", torch.cuda.memory_allocated())

            loss_value = loss(predictions, labels) # either model forward call or loss function must include sigmoid fn
            loss_value.backward()
            optimizer.step()
            optimizer.zero_grad()

            if scheduler is not None and scheduler.scheduler_type == "CyclicLR":
                scheduler.step()

            predictions = predictions.detach().cpu().numpy()
            labels = labels.cpu().numpy()
            activations = activations.detach().cpu().numpy()

            full_predictions = np.concatenate((full_predictions, predictions))
            full_labels = np.concatenate((full_labels, labels))
            full_activations = np.concatenate((full_activations, activations))

        if scheduler is not None and scheduler.scheduler_type != "CyclicLR":
            scheduler.step()
        
        # must have logger set up
        logging.info("\n\nEpoch %d (Final): " % epoch)
        logging.info("--Train Performance--")
        if verbose : 
            print("\nEpoch %d (Final): " % epoch)
            print("--Train Performance--")
        
        train_performance = test_metrics(
            prediction_np=full_predictions,
            label_np=full_labels,
            observed_prop=obs_prop_train,
            loss=loss,
            verbose = verbose
        )
        
        train_mean_dead_activations, train_mean_mostly_dead = check_dead_activations(
            full_activations, 
            verbose, 
            return_values=True
        )
        
        train_aucs.append(train_performance["auc"])
        train_losses.append(train_performance["loss"])
        train_mean_mostly_dead_list.append(train_mean_mostly_dead)
        
        val_preds, val_labels, val_ids, val_activations = predict(
            model=model,
            dataloader=val_dataloader,
            device=device
        )
        
        logging.info("--Validation Performance--")
        if verbose :
            print("--Validation Performance--")
        
        val_performance = test_metrics(
            prediction_np=val_preds,
            label_np=val_labels,
            observed_prop=obs_prop_train,
            loss=loss,
            verbose = verbose
        )
        
        val_mean_dead_activations, val_mean_mostly_dead = check_dead_activations(
            val_activations, 
            verbose, 
            return_values=True
        )
        
        val_aucs.append(val_performance["auc"])
        val_losses.append(val_performance["loss"])
        val_mean_mostly_dead_list.append(val_mean_mostly_dead)
        
        # save interim model
        model_filename = "epoch%d_checkpoint_model.pkl" % epoch
        # save model back to cpu
#         model.to('cpu')
        torch.save(model.state_dict(), output_dir.joinpath(param_dir_name, "interim_outputs", model_filename))
#         model.to(device)
        
        # save interim predictions
        preds_filename = "epoch%d_preds.feather" % epoch
        preds_np = np.concatenate((val_ids, val_preds, val_labels), 1)
        preds_df = pd.DataFrame(preds_np, columns=[id_var_name,"predicted_probability","outcome"])
        preds_df.to_feather(output_dir.joinpath(param_dir_name, "interim_outputs", preds_filename))
        
        # save best model for access at end of training
        if val_performance["auc"] > best_auc:
            logging.info("new best")
            if verbose:
                print("new best")
            torch.save(model, output_dir.joinpath(param_dir_name, "interim_outputs", "best_model.pt"))
            best_auc = val_performance["auc"]
            best_epoch = epoch
            early_stop_counter = 0
        else:
            early_stop_counter += 1
            if early_stop_counter == num_epoch_early_stop:
                logging.info("\n***********Early Stopping!\n")
                if verbose:
                    print("\n***********Early Stopping!\n")
                break
                
        epoch += 1
        logging.info("-"*100 + "\n\n")
        if verbose:
            print("-"*100 + "\n\n")
    logging.info("\n Best Epoch = %d \n" % (best_epoch))
    if verbose:
        print("\n Best Epoch = %d \n" % (best_epoch))
    model = torch.load(output_dir.joinpath(param_dir_name, "interim_outputs", "best_model.pt"))
    return model, {
        'best_auc': best_auc,
        'best_epoch': best_epoch,
        'train_aucs': train_aucs,
        'val_aucs': val_aucs,
        'train_losses': train_losses,
        'val_losses': val_losses,
        'mean_num_mostly_dead_activations_train': train_mean_mostly_dead_list,
        'mean_num_mostly_dead_activations_val': val_mean_mostly_dead_list
    }


# basic prediction function that takes a model and returns a numpy array of predictions and a numpy array of labels
def predict(
    model: torch.nn.Module,
    dataloader: torch.utils.data.DataLoader,
    device: torch.device = 'cpu',
) -> typing.Tuple[np.ndarray, np.ndarray]:
    """Given a torch model and a dataloader, return array of predictions and labels""" 
    with torch.no_grad():
        model.eval()
        full_predictions = np.empty((0,1))
        full_labels = np.empty((0,1))
        full_ids = np.empty((0,1))
        full_activations = np.empty((0,model.model.final_fc.in_features))
        for iteration, data in tqdm.tqdm(enumerate(dataloader, 0),
                                         total=len(dataloader),
                                         desc = "Progress through batches"):
#             images, labels, ids, added_data = data[0].to(device),data[1],data[2],data[3].to(device)

            activations = model.last_layer_activations(images)
            
            # boilerplate training iteration
            predictions = model(images, added_data)
            
            predictions = predictions.detach().cpu().numpy()
            labels = labels.numpy()
            ids = ids.numpy()
            activations = activations.detach().cpu().numpy()
            
            full_predictions = np.concatenate((full_predictions, predictions))
            full_labels = np.concatenate((full_labels, labels))
            full_ids = np.concatenate((full_ids, ids))
            full_activations = np.concatenate((full_activations, activations))
    return full_predictions, full_labels, full_ids, full_activations

# designed to work with predict, this function takes numpy arrays of predictions and labels and returns a few basic performance metrics
def test_metrics(
    prediction_np: np.ndarray,
    label_np: np.ndarray,
    loss: torch.nn.Module=torch.nn.BCELoss(),
    observed_prop: 'float64'=0.78,
    verbose: bool=True,
    return_metrics: bool=True,
) -> dict:
    pred_threshold = np.percentile(prediction_np, round((1-observed_prop)*100))
    pred_binary = (prediction_np >= pred_threshold)
    auc = metrics.roc_auc_score(label_np, prediction_np)
    loss_value = loss(torch.Tensor(prediction_np), torch.Tensor(label_np)).item()
    confusion_mat = metrics.confusion_matrix(label_np, pred_binary)
    accuracy = (confusion_mat[0,0] + confusion_mat[1,1])/np.sum(confusion_mat)
    sensitivity = confusion_mat[1,1]/np.sum(confusion_mat, 0)[1]
    specificity = confusion_mat[0,0]/np.sum(confusion_mat, 0)[0]
    metrics_dict = {
        "auc": auc,
        "loss": loss_value,
        "pred_threshold": pred_threshold,
        "confusion_matrix": confusion_mat,
        "accuracy": accuracy,
        "sensitivity": sensitivity,
        "specificity": specificity
    }
    logging.info(metrics_dict)
    if verbose : 
        print("Number of Predictions = ", len(prediction_np))
        print("AUC = ", auc)
        print("Loss = ", loss_value)
        print(confusion_mat)
        print(
            "(Threshold %f): Accuracy = %f\nSensitivity = %f\nSpecificity = %f \n" 
            % (pred_threshold, accuracy, sensitivity, specificity)
        )
    if return_metrics : 
        return metrics_dict
    
def check_dead_activations(activation_np: np.ndarray, verbose: bool=True, return_values: bool=False):
        dead_activations = (activation_np <= 0)
        row_sum = dead_activations.sum(axis=1)
        row_n = dead_activations.shape[1]
        col_sum = dead_activations.sum(axis=0)
        col_n = dead_activations.shape[0]
        mostly_dead = (col_sum/col_n >= 0.90)
        
        # mean number of dead activations across both neurons and images (same as mean(col_sum/col_n))
        mean_dead_activations = np.mean(row_sum/(row_n))
        
        logging.info(
            '''\nOn average, an image has %.1f dead activations out of %i (%.1f%%)\n
Across all activations, an activation is dead for %.1f out of %i images on average (%.1f%%)\n
%i out of %i activations/neurons are dead for >= 90%% of images (%.1f%%)\n''' % 
            (
                np.mean(row_sum), row_n, 100*np.mean(row_sum/(row_n)),
                np.mean(col_sum), col_n, 100*np.mean(col_sum/(col_n)),
                mostly_dead.sum(), len(mostly_dead), 100*mostly_dead.mean()
            )
        )
        if verbose :
            print(
                '''\nOn average, an image has %.1f dead activations out of %i (%.1f%%)\n 
Across all activations, an activation is dead for %.1f out of %i images on average (%.1f%%)\n 
%i out of %i activations/neurons are dead for >= 90%% of images (%.1f%%)\n''' % 
                (
                    np.mean(row_sum), row_n, 100*np.mean(row_sum/(row_n)),
                    np.mean(col_sum), col_n, 100*np.mean(col_sum/(col_n)),
                    mostly_dead.sum(), len(mostly_dead), 100*mostly_dead.mean()
                )
        )
        if return_values:
            return mean_dead_activations, mostly_dead.mean()

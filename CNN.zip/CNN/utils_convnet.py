"""Tools to help train and run a neural net over images."""

import torch
import torch.utils.data
import logging
import pandas as pd
import torchvision
import typing
import pathlib
import tqdm
import PIL.Image
import numpy as np
import matplotlib.pyplot
from sklearn import metrics, preprocessing
from torchvision import models
from facenet_pytorch import InceptionResnetV1


# plot a mugshot for eyeballing
def show_mugshot(images: typing.Union[torch.Tensor, np.ndarray]):
    if len(images.shape) == 4:
        # list of images: convert to grid
        images = torchvision.utils.make_grid(images)
    if isinstance(images, torch.Tensor):
        images = images.numpy().transpose([1, 2, 0])
    matplotlib.pyplot.imshow(images)
    
def config_pathlist_to_filepath(config_list):
    path = pathlib.Path()
    for path_item in config_list:
        path = path.joinpath(path_item)
    return path
    
def train_test_split_simple(data: pd.DataFrame, p_train: 'float32'=0.6, seed: 'int32'=None): 
    """Split a dataframe into a train and test set"""
    np.random.seed(seed)
    index = np.random.rand(len(data)) < p_train
    train_data = data[index]
    test_data = data[~index]
    return train_data, test_data

def add_arrest_info(arrest_df: pd.DataFrame, charge_df:pd.DataFrame, crime_dict: dict):
    arrest_df['arrest_id'] = arrest_df['arrest_id'].astype(int)
    charge_df['arrest_id'] = charge_df['arrest_id'].astype(int)

    arrest_charge_df = pd.merge(arrest_df, charge_df[["arrest_id", "arrest_type", "description"]], how="left", on="arrest_id")
    arrest_charge_df["description"] = arrest_charge_df["description"].cat.add_categories('MISSING DESCRIPTION')
    arrest_charge_df["description"] = arrest_charge_df["description"].fillna("MISSING DESCRIPTION")

    crime_vars = []
    for crime_key in crime_dict:
        crime_regex = '({})'.format('|'.join(crime_dict[crime_key]))
        var_name = crime_key + "_crime_flag"
        crime_vars.append(var_name)
        arrest_charge_df[var_name] = arrest_charge_df["description"].str.contains(crime_regex)

    arrest_charge_df["felony_flag"] = arrest_charge_df["arrest_type"] == "Felony" 
    cols = ["felony_flag"] + crime_vars
    arrest_charge_collapsed = arrest_charge_df.groupby("arrest_id")[cols].any()
    arrest_df = pd.merge(arrest_df, arrest_charge_collapsed, how="left", on="arrest_id") 
    arrest_df["arrest_year"] = pd.DatetimeIndex(arrest_df["arrest_date"]).year.astype('category')
    departments = arrest_df["arrest_by"].value_counts()[:11].index.values
    arrest_df["arrest_by"] = np.where(
        arrest_df["arrest_by"].isin(departments), 
        arrest_df["arrest_by"], 
        "other"
    )
    return arrest_df

def add_release_outcome_and_filter(arrest_df: pd.DataFrame, outcome_df:pd.DataFrame):
    arrest_df['arrest_id'] = arrest_df['arrest_id'].astype(int)
    outcome_df['arrest_id'] = outcome_df['arrest_id'].astype(int)
    
    arrest_outcome_df = pd.merge(
        arrest_df, 
        outcome_df[["arrest_id", "arrest_final_outcome"]], 
        how='left', on='arrest_id'
    )
    arrest_outcome_df = arrest_outcome_df.dropna(subset = ["arrest_final_outcome"])
    arrest_outcome_df = arrest_outcome_df[arrest_outcome_df["arrest_final_outcome"] != "Filtered"]
    arrest_outcome_df["arrest_final_outcome"] = arrest_outcome_df["arrest_final_outcome"].str.contains('Released')
    arrest_outcome_df["arrest_final_outcome"] = arrest_outcome_df["arrest_final_outcome"].astype("int")
    
    return arrest_outcome_df

def prep_added_data(df: pd.DataFrame, added_data_colnames: list, id_colname: str):
    if len(added_data_colnames) == 0:
        df_dummies = df
    else:
        cols = added_data_colnames + [id_colname]
        dummies = pd.get_dummies(df[cols])
        dummy_colnames = dummies.columns.to_list()
        # get rid of arrest_id, so we don't scale fit
        dummy_colnames.remove(id_colname)
        scaler = preprocessing.MinMaxScaler()
        dummies[dummy_colnames] = scaler.fit_transform(dummies[dummy_colnames])
        df_dummies = pd.merge(
            df.drop(added_data_colnames, axis=1), 
            dummies, how="left", on=id_colname
        )        
    return df_dummies, dummy_colnames

class ImageDataset(torch.utils.data.Dataset):
    """Dataset for images plus structured data"""

    def __init__(
        self,
        image_directory: typing.Union[str, pathlib.Path],
        label_df: pd.DataFrame,
        id_var_name: str,
        response_var_name: str,
        added_data_colnames: typing.Optional[typing.Sequence[str]]=None,
        image_transformation: typing.Optional[typing.Callable]=None,
    ):
        """Create a dataloader from image data.

        Args:
            image_directory: Path to directory containing images, with names that match column in label_df.
            label_df: Dataframe containing labels and all structured data to be used in the model.
            id_var_name: String with column name for id variable in label_df
            response_var_name: String with column name for dependent variable in label_df.
            added_data_colnames: List of column names of structured data to be used in the model.
            image_transformation: Optional transformation to be applied on a sample.
        """
        self.image_directory = pathlib.Path(image_directory)
        self.df = label_df.copy()
        self.added_data = self.df[added_data_colnames]
        self.transform = image_transformation
        self.id_var_name = [id_var_name]
        if response_var_name not in self.df.columns:
            raise ValueError("Labels not in given DataFrame.")
        self.label_cols = [response_var_name]

    def __len__(self):
        return self.df.shape[0]

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        # import images
        image_name = self.image_directory.joinpath(self.df["image_number"].iloc[idx] + ".jpg")
        image = PIL.Image.open(image_name)
        if self.transform:
            image = self.transform(image)
        if not isinstance(image, torch.Tensor):
            image = torchvision.transforms.ToTensor()(image)

        # get label vector
        image_label = torch.tensor(self.df[self.label_cols].iloc[idx, :].values, dtype=torch.float32,)
        
        # get id for later identification
        id_var = torch.tensor(self.df[self.id_var_name].iloc[idx, :].values, dtype=torch.float32,)
        
        # get extra data vector
        added_data = torch.tensor(self.added_data.iloc[idx, :].values, dtype=torch.float32,)

        # answer format expects dict
        return image, image_label, id_var, added_data

# Remove Labels for predictions
class MultiLabelImageDataset(torch.utils.data.Dataset):
    """Dataset for images plus structured data"""

    def __init__(
        self,
        image_directory: typing.Union[str, pathlib.Path],
        label_df: pd.DataFrame,
        id_var_name: str,
        response_var_colnames: typing.Optional[typing.Sequence[str]],
        image_transformation: typing.Optional[typing.Callable]=None,
    ):
        """Create a dataloader from image data.

        Args:
            image_directory: Path to directory containing images, with names that match column in label_df.
            label_df: Dataframe containing labels and all structured data to be used in the model.
            id_var_name: String with column name for id variable in label_df
            response_var_name: String with column name for dependent variable in label_df.
            added_data_colnames: List of column names of structured data to be used in the model.
            image_transformation: Optional transformation to be applied on a sample.
        """
        self.image_directory = pathlib.Path(image_directory)
        self.df = label_df.copy()
        self.transform = image_transformation
        self.id_var_name = [id_var_name]
        self.response_var_colnames = response_var_colnames
        self.labels_dict = None

    def __len__(self):
        return self.df.shape[0]
    
    def __print__(self):
        return labels_dict

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()
            
        # import images
        image_name = self.image_directory.joinpath(self.df["image_number"].iloc[idx] + ".jpg")
        image = PIL.Image.open(image_name)
        if self.transform:
            image = self.transform(image)
        if not isinstance(image, torch.Tensor):
            image = torchvision.transforms.ToTensor()(image)

        # get label vector
        labels_dict = {}
        for col in self.response_var_colnames:
            labels_dict[col] = torch.tensor(self.df[[col]].iloc[idx, :].values, dtype=torch.float32,)
                
        # get id for later identification
        id_var = torch.tensor(self.df[self.id_var_name].iloc[idx, :].values, dtype=torch.float32,)
        self.labels_dict = labels_dict
        
        # answer format expects dict
        return image, labels_dict, id_var
    # Remove Labels for predictions

# Same as above, here we remove the labels since we don't have these for generated images
# Now reads in pred_df for labels --> this is a len(Images) df but with only one column
class MultiLabelPredictionImageDataset(torch.utils.data.Dataset):
    """Dataset for images plus structured data"""

    def __init__(
            self,
            image_directory: typing.Union[str, pathlib.Path],
            label_df: pd.DataFrame,
            id_var_name: str,
            # response_var_colnames: typing.Optional[typing.Sequence[str]],
            image_transformation: typing.Optional[typing.Callable] = None,
    ):
        """Create a dataloader from image data.
        Args:
            image_directory: Path to directory containing images, with names that match column in label_df.
            label_df: Dataframe containing labels and all structured data to be used in the model.
            id_var_name: String with column name for id variable in label_df
            response_var_name: String with column name for dependent variable in label_df.
            added_data_colnames: List of column names of structured data to be used in the model.
            image_transformation: Optional transformation to be applied on a sample.
        """
        self.image_directory = pathlib.Path(image_directory)
        self.df = label_df.copy()
        self.transform = image_transformation
        self.id_var_name = [id_var_name]
        # self.response_var_colnames = response_var_colnames

    # This works since df contains a single column of integers ranging from 1-len(Images)
    def __len__(self):
        return self.df.shape[0]

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        # import images
        # now get the image name simply as the integer in df (numbered 1 - len(Images))
        # may need to collectively re-name all images that the GAN produces to something line "gen_image" and append id
        # gen_image_id is the col name for the len id:
        # image_name = self.image_directory.joinpath("seed" + str(self.df["gen_image_id"].iloc[idx]).zfill(4) + ".jpg")       
        # image_name = self.image_directory.joinpath("image" + str(self.df["gen_image_id"].iloc[idx]).zfill(4) + "-target.jpg")
        image_name = self.image_directory.joinpath("seed_200_var_" + str(self.df["gen_image_id"].iloc[idx]) + ".png")


        print(image_name)
        image = PIL.Image.open(image_name)
        if self.transform:
            image = self.transform(image)
        if not isinstance(image, torch.Tensor):
            image = torchvision.transforms.ToTensor()(image)
        # get label vector
        # labels_dict = {}
        # for col in self.response_var_colnames:
        #     labels_dict[col] = torch.tensor(self.df[[col]].iloc[idx, :].values, dtype=torch.float32, )

        # get id for later identification
        id_var = torch.tensor(self.df[self.id_var_name].iloc[idx, :].values, dtype=torch.float32, )

        # answer format expects dict
        return image, id_var





        

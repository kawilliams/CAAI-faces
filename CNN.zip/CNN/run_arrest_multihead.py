import torch
from torchvision import models
from pytorch_lightning.core.lightning import LightningModule
from pytorch_lightning import Trainer
import pytorch_lightning as pl
from torch.optim import Adam
from torch.utils.data import DataLoader
import pandas as pd
import yaml
import torch
from torchvision import transforms
# from hyperopt import fmin, tpe, hp, Trials, STATUS_OK
import torch.utils.data
# from torch.optim.lr_scheduler import MultiStepLR, CyclicLR
import pathlib
from hyperopt import fmin, tpe, hp, Trials, STATUS_OK
import training_functions_classification as training_functions
import utils_convnet_classification as utils_convnet
import numpy as np
from tqdm import tqdm
import pytorch_lightning.metrics.functional as plm
from pytorch_lightning.loggers import NeptuneLogger, CometLogger
from torch.optim.lr_scheduler import MultiStepLR, CyclicLR, ReduceLROnPlateau
import typing
import argparse
from pytorch_lightning.callbacks.early_stopping import EarlyStopping
from pytorch_lightning.callbacks import ModelCheckpoint
import copy
from facenet_pytorch import InceptionResnetV1
import matplotlib.pyplot as plt
import seaborn as sns

global param_set_id, config
torch.manual_seed(912)
image_directory = pathlib.Path.home() / "projects" / "2019-042-faces" / "mugshots"
data_directory = pathlib.Path.home() / "projects" / "2019-042-faces" / "data" / "clean"


# config_filepath = 'config/c00_test.yaml'

# arguments = {}

class MultiHeadArrestDataModule(pl.LightningDataModule):

    def __init__(self, config):
        super().__init__()

        self.config = config
        #         self.setup_arguments()
        self.arrest_df, self.charge_df, self.outcome_df = self.read_dataset()
        self.arrest_df_altered = self.prepare_labels()
        self.arrest_df_dummies = None
        self.train_dataset = None
        self.val_dataset = None
        self.test = None
        self.train_dataset_no_transform = None

    #         self.val_df = None
    #         self.train_df = None

    def read_dataset(self):
        arrest_df = pd.read_feather(data_directory.joinpath("mcso", "arrest_train-0.0.1.feather"))
        charge_df = pd.read_feather(data_directory.joinpath("mcso", "arrest_charge-0.0.1.feather"))
        outcome_df = pd.read_feather(data_directory.joinpath("outcomes", "arrest_outcome-0.0.1.feather"))
        return arrest_df, charge_df, outcome_df

    def min_class_sampler(self, data, colname, target):
        class_1 = len(data[(data[colname] == 1)])
        class_0 = len(data[(data[colname] == 0)])
        ratio = class_1 / class_0
        alpha = (ratio / target)
        class_0_diff = int(round((alpha * class_0) - class_0))
        sampled_index = np.random.choice(data[data[colname] == 0].index.values, size=class_0_diff, replace=False)
        data_resized = data.append(data.loc[sampled_index], ignore_index=True)
        return data_resized

    def prepare_labels(self):
        image_directory = pathlib.Path(pathlib.Path.home() / "projects" / "2019-042-faces" / "mugshots").joinpath(
            'processed')
        self.arrest_df = utils_convnet.add_arrest_info(self.arrest_df, self.charge_df, self.config["crime_dict"])
        arrest_outcome_df = utils_convnet.add_release_outcome_and_filter(self.arrest_df, self.outcome_df)
        images = [filename.stem for filename in pathlib.Path(image_directory).glob("*.jpg")]
        arrest_outcome_df["image_exists"] = arrest_outcome_df["image_number"].isin(images)
        return arrest_outcome_df[arrest_outcome_df["image_exists"]]

    def split_data(self, arrest_df_dummies):
        random_train_var_cutoff = arrest_df_dummies["random_train_var"].max() * self.config["train_proportion"]
        train_df = arrest_df_dummies[arrest_df_dummies["random_train_var"] <= random_train_var_cutoff]
        val_df = arrest_df_dummies[arrest_df_dummies["random_train_var"] > random_train_var_cutoff]
        return train_df, val_df

    def transform_train(self, train_df):
        transform_train = transforms.Compose(
            [
                transforms.RandomRotation(45),
                transforms.ToTensor(),
                # default mean values from imagenet (recommended for pretrained models)
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ]
        )

        train_dataset = utils_convnet.MultiLabelImageDataset(
            image_directory=pathlib.Path.home() / "projects" / "2019-042-faces" / "mugshots" / "processed",
            label_df=train_df,
            id_var_name=self.config["id_var_name"],
            response_var_colnames=self.config["response_var_colnames"],
            image_transformation=transform_train
        )

        return train_dataset

    def transform_val(self, val_df):
        transform_val = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ]
        )

        val_dataset = utils_convnet.MultiLabelImageDataset(
            ## TODO Fix image_directory paths
            image_directory=pathlib.Path.home() / "projects" / "2019-042-faces" / "mugshots" / "processed",
            label_df=val_df,
            id_var_name=self.config["id_var_name"],
            response_var_colnames=self.config["response_var_colnames"],
            image_transformation=transform_val
        )

        return val_dataset

    #     def train_dataloader_no_transform(self):
    #         val_dataloader = torch.utils.data.DataLoader(self.val_dataset, num_workers=32, batch_size=self.config["batch_size"])
    #         return val_dataloader
    #     def no_transform_train(self, train_df):
    #         train_dataset_no_transform = utils_convnet.ImageDataset(
    #         image_directory=self.arguments["image_directory"],
    #         label_df=train_df,
    #         id_var_name=self.config["id_var_name"],
    #         response_var_name=self.config["response_variable"],
    #         added_data_colnames=self.config["added_data_colnames"],
    #         image_transformation=transform_val
    #         )
    #         train_dataloader_no_transform = torch.utils.data.DataLoader(
    #         train_dataset_no_transform, batch_size=self.config["batch_size"]
    #         )
    #         torch.save(train_dataloader_no_transform, self.config["output_directory"].joinpath("train_dataloader_no_transform.pth"))
    #         return train_dataset_no_transform

    def no_transform_train(self, train_df):
        transform_train = transforms.Compose(
            [
                transforms.ToTensor(),
                # default mean values from imagenet (recommended for pretrained models)
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ]
        )

        no_transform_train_dataset = utils_convnet.MultiLabelImageDataset(
            image_directory=pathlib.Path.home() / "projects" / "2019-042-faces" / "mugshots" / "processed",
            label_df=train_df,
            id_var_name=self.config["id_var_name"],
            # wont work without definining these names in the dataloader (setup)
            response_var_colnames=self.config["response_var_colnames"],
            image_transformation=transform_train
        )

        return no_transform_train_dataset

    def prepare_data(self):
        return

    def setup(self, stage=None):
        # race
        self.arrest_df_altered['white'] = self.arrest_df_altered['race'] == 'W'
        # sex
        self.arrest_df_altered['male'] = self.arrest_df_altered['sex'] == 'M'
        train_df, val_df = self.split_data(self.arrest_df_altered)
        # age
        median_age = train_df.age_arrest.median()
        train_df['greater_than_median_age'] = train_df['age_arrest'] > median_age
        val_df['greater_than_median_age'] = val_df['age_arrest'] > median_age

        train_df = self.min_class_sampler(data=train_df, colname='arrest_final_outcome',
                                          target=self.config["target_ratio"])

        self.train_dataset = self.transform_train(train_df)
        self.val_dataset = self.transform_val(val_df)
        self.train_dataset_no_transform = self.no_transform_train(train_df)

    def train_dataloader(self):
        train_dataloader = torch.utils.data.DataLoader(self.train_dataset, num_workers=32,
                                                       batch_size=self.config["batch_size"])
        return train_dataloader

    def val_dataloader(self):
        val_dataloader = torch.utils.data.DataLoader(self.val_dataset, num_workers=32,
                                                     batch_size=self.config["batch_size"])
        return val_dataloader

    def test_dataloader(self):
        test_dataloader = torch.utils.data.DataLoader(self.val_dataset, num_workers=32,
                                                      batch_size=self.config["batch_size"])
        return test_dataloader

    def train_dataloader_no_transform(self):
        train_dataloader_no_transform = torch.utils.data.DataLoader(self.train_dataset_no_transform, num_workers=32,
                                                                    batch_size=self.config["batch_size"])
        return train_dataloader_no_transform


class Identity(LightningModule):
    def __init__(self, in_features):
        super(Identity, self).__init__()
        self.in_features = in_features

    def configure_optimizers(self):
        return Adam(self.parameters(), lr=1e-3)

    def forward(self, x):
        return x


class MultiTaskClassification(LightningModule):
    def __init__(self, config):
        super(MultiTaskClassification, self).__init__()

        model = self.model_selector(config["model_architecture"])
        self.cnn = model
        final_layer_name = self.find_final_layer_name(self.cnn)

        self.cnn.fc_classifiers = torch.nn.ModuleDict()
        for col in config['response_var_colnames']:
            self.cnn.fc_classifiers[col] = torch.nn.Linear(getattr(self.cnn, final_layer_name).in_features, 1,
                                                           bias=True)

        self.sigmoid = torch.nn.Sigmoid()
        self.n_activations = getattr(self.cnn, final_layer_name).in_features
        setattr(self.cnn, final_layer_name, Identity(getattr(self.cnn, final_layer_name).in_features))
        self.save_hyperparameters()
        self.predictions = None
        self.labels = None
        self.ids = None
        self.config = config
        self.lr_shape = self.config['lr_shape']
        self.learning_rate = 9.549925860214358e-07
        self.current_weights = []
        self.previous_weights, self.shared_names = self.get_weights()
        self.weights_dict = []
        self.epoch_counter = 0

    def get_weights(self):
        shared_names = []
        weights_array = []
        weight_change_averages = []
        for name, params in self.cnn.named_parameters():
            if 'weight' in name and 'bn' not in name:
                # for the love of god dont remove clone
                weights_array.append(params.detach().clone())
                shared_names.append(name)
        return weights_array, shared_names

    def model_selector(self, model_name):
        return {
            'resnet-18': models.resnet18(pretrained=True),
            'resnet-50': models.resnet50(pretrained=True),
            'inception_resnet_v1': InceptionResnetV1(
                classify=True,
                pretrained='vggface2',
                num_classes=1
            )
        }.get(model_name, models.resnet18(pretrained=True))

    def find_final_layer_name(self, model):
        layers = []
        for name, param in model.named_parameters():
            layer = name.split('.')[0]
            if layer not in layers:
                layers.append(layer)
        return layers[-1]

    def setup_lr_param_groups(self, lr_highest):
        layers = []
        for name, param in self.named_parameters():
            layer = name.split('.')[1]
            if layer not in layers:
                layers.append(layer)

        # define function that defines lr by depth
        if self.lr_shape == "steep_decay":
            def lr_shape_function(depth):
                return lr_highest / (depth ** 2.5 + 1)
        elif self.lr_shape == "gentle_decay":
            def lr_shape_function(depth):
                return lr_highest / (depth ** 0.5 + 1)
        else:
            def lr_shape_function(depth):
                return lr_highest

        param_groups = []
        depth = len(layers) - 1
        for layer in layers:
            param_groups.append({
                'name': layer,
                'lr_highest': lr_highest,
                'lr_shape': self.lr_shape,
                'params': getattr(self.cnn, layer).parameters(),
                'lr': lr_shape_function(depth)
            })
            depth -= 1
        return param_groups

    def configure_optimizers(self):
        optimizer = Adam(self.setup_lr_param_groups(self.learning_rate))
        return {
            'optimizer': Adam(self.setup_lr_param_groups(self.learning_rate)),
            'lr_scheduler': ReduceLROnPlateau(optimizer),
            'monitor': 'val_loss'
        }

    def last_layer_activations(self, images):
        return self.cnn(images)

    # TODO: Set up for single multihead w. continuous outcomes
    def forward(self, image):
        x = self.cnn(image)
        y_preds = {}
        for col in self.config['response_var_colnames']:
            y_preds[col] = self.cnn.fc_classifiers[col](x)
        return y_preds

    def training_step(self, batch, batch_idx):
        images, labels, ids = batch
        activations = self.last_layer_activations(images)
        y_hats = self(images)
        loss_func = torch.nn.BCEWithLogitsLoss()
        losses = {}
        total_loss = 0
        p_hats = {}
        for col in self.config['response_var_colnames']:
            current_loss = loss_func(y_hats[col], labels[col])
            total_loss += current_loss
            losses[col] = current_loss
            p_hats[col] = self.sigmoid(y_hats[col])
            self.log('train_loss_' + col, current_loss, sync_dist=True)
        dead_activations = (activations <= 0)
        dead_activation_sums = (dead_activations.sum(axis=0))
        self.log('train_loss', total_loss, sync_dist=True)
        return {'loss': total_loss, 'loss_dict': losses, 'p_hat': p_hats,
                'dead_activation_sums': dead_activation_sums.detach(), 'labels': labels, 'ids': ids}

    def validation_step(self, batch, batch_idx):
        images, labels, ids = batch
        activations = self.last_layer_activations(images)
        y_hats = self(images)
        loss_func = torch.nn.BCEWithLogitsLoss()
        losses = {}
        total_loss = 0
        p_hats = {}
        for col in self.config['response_var_colnames']:
            current_loss = loss_func(y_hats[col], labels[col])
            total_loss += current_loss
            losses[col] = current_loss
            p_hats[col] = self.sigmoid(y_hats[col]).detach()
            self.log('val_loss_' + col, current_loss, sync_dist=True)
        dead_activations = (activations <= 0)
        dead_activation_sums = (dead_activations.sum(axis=0))
        self.log('val_loss', total_loss, sync_dist=True)
        return {'loss': total_loss, 'loss_dict': losses, 'p_hat': p_hats,
                'dead_activation_sums': dead_activation_sums.detach(), 'labels': labels, 'ids': ids}

    def training_epoch_end(self, outputs):
        for col in self.config['response_var_colnames']:
            pred = torch.cat([x['p_hat'][col] for x in outputs])
            target = torch.cat([x['labels'][col] for x in outputs])
            #             self.log('train_accuracy_'+col, plm.accuracy(pred, target))
            self.log('train_auc_' + col, plm.auroc(pred.flatten(), target.flatten()), sync_dist=True)
        #             self.log('train_f1_score_'+col, plm.f1_score(pred, target))

        dead_activation_sums = torch.stack([x['dead_activation_sums'] for x in outputs]).sum(axis=0).double()
        avg_prop_dead_per_image = torch.mean(dead_activation_sums / len(pred.flatten()))
        mostly_dead = (dead_activation_sums / len(pred.flatten()) >= 0.9)
        prop_nodes_mostly_dead = torch.mean(mostly_dead.double())

        self.log('train_avg_prop_dead_per_image', avg_prop_dead_per_image.item())
        self.log('train_prop_nodes_mostly_dead', prop_nodes_mostly_dead.item())

        self.plot_weight_changes()
        self.epoch_counter += 1

    def plot_weight_changes(self):
        weights_array = []
        weight_change_averages = []
        weight_change_averages_scaled = []

        self.current_weights, shared_names = self.get_weights()

        if self.epoch_counter == 0:
            self.previous_weights = self.current_weights
            return

        #
        for i in range(len(self.current_weights)):
            weight_change_averages.append(abs(self.current_weights[i] - self.previous_weights[i]).mean().detach())

        weight_change_averages_scaled = [x / sum(weight_change_averages) for x in weight_change_averages]
        self.weights_dict.append({shared_names[i]: weight_change_averages_scaled[i] for i in range(len(shared_names))})

    #         self.weights_dict.append({shared_names[i] : weight_change_averages[i] for i in range(len(shared_names))})

    #         current_dict = {shared_names[i] : weight_change_averages[i] for i in range(len(shared_names))}
    #         weight_names = current_dict.keys()
    #         for weight_name in weight_names:
    #             y = current_dict[weight_name]
    #             self.log('avg_weights'+weight_name, y.item())
    #         self.previous_weights = self.current_weights

    def validation_epoch_end(self, outputs):
        for col in self.config['response_var_colnames']:
            pred = torch.cat([x['p_hat'][col] for x in outputs])
            target = torch.cat([x['labels'][col] for x in outputs])
            #             self.log('val_accuracy_'+col, plm.accuracy(pred, target))
            self.log('val_auc_' + col, plm.auroc(pred.flatten(), target.flatten()), sync_dist=True)
        #             self.log('val_f1_score_'+col, plm.f1_score(pred, target))

        dead_activation_sums = torch.stack([x['dead_activation_sums'] for x in outputs]).sum(axis=0).double()
        avg_prop_dead_per_image = torch.mean(dead_activation_sums / len(pred.flatten()))
        mostly_dead = (dead_activation_sums / len(pred.flatten()) >= 0.9)
        prop_nodes_mostly_dead = torch.mean(mostly_dead.double())

        self.log('val_avg_prop_dead_per_image', avg_prop_dead_per_image.item())
        self.log('val_prop_nodes_mostly_dead', prop_nodes_mostly_dead.item())


def predict(
        model: torch.nn.Module,
        config: dict,
        dataloader: torch.utils.data.DataLoader,
        device: torch.device = 'cpu'
):
    """Given a torch model and a dataloader, return array of predictions and labels"""
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)
    with torch.no_grad():
        model.eval()
        full_activations = torch.empty((0, model.n_activations))
        predictions_array = []
        labels_array = []
        predictions = []
        labels = []

        full_predictions = {}
        full_labels = {}
        for iteration, data in tqdm(enumerate(dataloader, 0),
                                    total=len(dataloader),
                                    desc="Progress through batches"):

            images, labels, ids = data[0].to(device), data[1], data[2]
            activations = model.last_layer_activations(images)
            full_activations = torch.cat((full_activations, activations.detach().cpu()))
            y_preds = model(images)
            p_hats = {}
            for col in config['response_var_colnames']:
                p_hats[col] = model.sigmoid(y_preds[col]).detach().cpu()
            p_hats['ids'] = ids
            labels['ids'] = ids
            predictions_array.append(p_hats)
            labels_array.append(labels)

        for col in config['response_var_colnames']:
            full_predictions[col] = torch.cat([x[col] for x in predictions_array]).flatten()
            full_labels[col] = torch.cat([x[col] for x in labels_array]).flatten()
        full_predictions['ids'] = torch.cat([x['ids'] for x in predictions_array]).flatten()
        full_labels['ids'] = torch.cat([x['ids'] for x in labels_array]).flatten()
    return full_predictions, full_labels, full_activations


def parse_args() -> typing.Dict[str, typing.Any]:
    """Get command line arguments, with defaults set for local testing."""
    parser = argparse.ArgumentParser("Use a pre-trained model to predict binary outcome")
    parser.add_argument("--config_filepath")
    #     parser.add_argument('--gpus', default=-1)
    #     parser.add_argument('--notification_email', type=str, default='celiajm@email.com')

    arguments = vars(parser.parse_args())
    return arguments, parser


def main():
    global param_set_id

    arguments, parser = parse_args()
    arguments["config_filepath"] = pathlib.Path(arguments["config_filepath"])
    config = yaml.load(open(arguments["config_filepath"]), Loader=yaml.FullLoader)
    config["image_directory"] = pathlib.Path(config["image_directory"])
    config["image_directory"] = config["image_directory"].joinpath(config["image_crop_type"])
    config["output_directory"] = utils_convnet.config_pathlist_to_filepath(config["output_directory"])
    config["output_directory"] = config["output_directory"].joinpath(config["model_name"])
    config["output_directory"].mkdir(parents=True, exist_ok=True)

    param_set_id = 0
    run_model(config)
    return


def run_model(config):
    global param_set_id

    param_dir_name = "param_set_" + str(param_set_id)
    config["output_directory"].joinpath(str(param_dir_name)).mkdir(parents=True, exist_ok=True)

    comet_logger = CometLogger(
        api_key="oEPa4zli6mJsyRyTWXQtqcSzC",
        workspace="jonasknecht",
        project_name=config["comet_logger_project"],
        experiment_name=config["model_name"]
    )

    #     comet_logger = CometLogger(
    #     api_key="G2Qv8OvEBimtHFcPxLTp95kYs",
    #     workspace="celiajm",
    #     project_name=config["comet_logger_project"],
    #     experiment_name = config["model_name"]
    #     )

    # Celia Comet:
    #     if isinstance(param_set_id , int):
    #         comet_logger = CometLogger(
    #         api_key="G2Qv8OvEBimtHFcPxLTp95kYs",
    #         workspace="celiajm",
    #         project_name=config["comet_logger_project"],
    #         experiment_name= config["model_name"]
    #         )
    # Jonas Comet:
    if isinstance(param_set_id, int):
        comet_logger = CometLogger(
            api_key="oEPa4zli6mJsyRyTWXQtqcSzC",
            workspace="jonasknecht",
            project_name=config["comet_logger_project"],
            experiment_name=config["model_name"]
        )

    comet_logger.experiment.add_tags([config['model_name'], 'tuning'])

    checkpoint_callback = ModelCheckpoint(
        monitor='val_auc_arrest_final_outcome',
        dirpath=config["output_directory"].joinpath(str(param_dir_name)),
        filename='checkpoint-model-{epoch:02d}-{val_auc_arrest_final_outcome:.2f}',
        save_top_k=3,
        mode='max'
    )

    early_stop_callback = EarlyStopping(
        monitor='val_loss',
        min_delta=0.00,
        patience=config['patience'],
        verbose=True,
        mode='min'
    )

    if isinstance(param_set_id, int):
        early_stop_callback = EarlyStopping(
            monitor='val_loss',
            min_delta=0.00,
            patience=config['patience'],
            verbose=True,
            mode='min'
        )

    #     model = BinaryClassification(InceptionResnetV1(
    #             classify=True,
    #             pretrained='vggface2',
    #             num_classes= 1
    #         ), config)

    #     model = MultiTaskClassification(models.resnet18(pretrained=True), config)
    
    model = MultiTaskClassification(config)
    imagenet_dm = MultiHeadArrestDataModule(config)
    trainer = Trainer(distributed_backend="ddp", max_epochs=config["max_epochs"], logger=comet_logger,
                      callbacks=[early_stop_callback, checkpoint_callback], gpus=-1, precision=16)

    model.hparams.learning_rate = config['tuner_lr']
    model.learning_rate = config['tuner_lr']
    trainer.fit(model, imagenet_dm)

    checkpoint = torch.load(checkpoint_callback.best_model_path)
    model.load_state_dict(checkpoint['state_dict'])

    actual_val_dataloader = imagenet_dm.val_dataloader()
    actual_train_dataloader = imagenet_dm.train_dataloader_no_transform()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    train_preds, train_labels, train_activations = predict(
        model=model,
        config=config,
        dataloader=actual_train_dataloader,
        device=device
    )
    val_preds, val_labels, val_activations = predict(
        model=model,
        config=config,
        dataloader=actual_val_dataloader,
        device=device
    )

    train_preds_df = pd.DataFrame(train_preds)
    train_labels_df = pd.DataFrame(train_labels)
    val_preds_df = pd.DataFrame(val_preds)
    val_labels_df = pd.DataFrame(val_labels)

    train_preds_labels_df = pd.merge(train_preds_df, train_labels_df, on='ids', suffixes=['_pred', '_label'])
    val_preds_labels_df = pd.merge(val_preds_df, val_labels_df, on='ids', suffixes=['_pred', '_label'])
    train_preds_labels_df["train_val"] = "train"
    val_preds_labels_df["train_val"] = "val"
    preds_labels_df = pd.concat([train_preds_labels_df, val_preds_labels_df])

    preds_labels_df.rename({'ids': config['id_var_name']})
    preds_labels_df = preds_labels_df.reset_index()
    preds_labels_df.to_feather(config["output_directory"].joinpath(param_dir_name, "full_sample_predictions.feather"))

    for col in config['response_var_colnames']:
        pred_col = col + '_pred'
        label_col = col + '_label'
        print('train ', col)
        training_functions.test_metrics(train_preds_labels_df[pred_col], train_preds_labels_df[label_col])
        print('val ', col)
        performance = training_functions.test_metrics(val_preds_labels_df[pred_col], val_preds_labels_df[label_col])

    param_set_name = str(param_set_id)
    if isinstance(param_set_id, int):
        param_set_id += 1

    final_df = pd.DataFrame()
    layer_names = model.weights_dict[0].keys()
    for epoch in range(len(model.weights_dict)):
        for layer_name in model.weights_dict[epoch].keys():
            temp_dict = {'epoch': epoch, 'layer_name': layer_name,
                         'average_change': model.weights_dict[epoch][layer_name].cpu().item()}
            current_df = pd.DataFrame([temp_dict])
            final_df = pd.concat([current_df, final_df])
    final_df['layer_name'] = final_df['layer_name'].map(lambda x: x.replace('.weight', ''))
    pivoted_heatmap_df = final_df.pivot("layer_name", "epoch", "average_change")

    layer_names = map(lambda x: x.replace('.weight', ''), layer_names)
    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(pivoted_heatmap_df.loc[layer_names], linewidths=0.5, cmap='coolwarm').set_title(
        'Share of total average weight change, by layer')
    comet_logger.experiment.log_figure(figure=plt)

    #     fig, ax = plt.subplots(figsize=(11,9))
    #     sns.heatmap(pivoted_heatmap_df.loc[layer_names], linewidths=0.5).set_title('Share of total average weight change, by layer')
    #     comet_logger.experiment.log_figure(figure=plt)

    #     print(model.weights_dict)
    #     weight_names = model.weights_dict[0].keys()
    #     for weight_name in weight_names:
    #         y = [d[weight_name] for d in model.weights_dict]
    #         print(y)
    #         plt.plot(y)
    #         plt.xlabel('Epoch')
    #         plt.ylabel(weight_name)
    #         plt.legend()
    #         plt.title('Mean weight difference between epochs, '+weight_name)
    #         plt.grid(True)
    #         comet_logger.experiment.log_figure(figure=plt)

    torch.save(model, config['output_directory'].joinpath('final_model.pt'))

    return {
        'loss': 1 - performance["auc"],
        'status': STATUS_OK,
        'auc': performance["auc"],
        'param_set_id': param_set_name,
        'num_rows_train_set': len(train_preds_df),
        'num_rows_val_set': len(val_preds_df),
    }


if __name__ == '__main__':
    main()
